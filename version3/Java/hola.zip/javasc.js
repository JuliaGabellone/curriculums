function decirToma() {
	alert ("Toma!");
	alert (" Jajaja");
}

function decir(frase) {
	alert (frase);
}

function ponerfondorojo() {
	//document.getElementById("miParrafo").style.background="red"; 
}

function sacarfondorojo() {
	//document.getElementById("miParrafo").style.background="white"; 
}
function ponerestilo() {
	document.getElementById("xxx").setAttribute("class","items");
}
function ponerfondorojo() {
	document.getElementById("miParrafo").style.display="none"; 
}
function sacarfondorojo() {
	document.getElementById("miParrafo").style.display="block"; 
}
