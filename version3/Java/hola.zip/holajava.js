<html>
	<head>
		<script type="text/javascript" src="pagina.js"> </script>
	</head>	
	<body>
		<h1>Mariposas  </h1>
		
		<img src="mariposas.jpg"/>
		
		
		<div>
		
		<h2>Orugas </h2>
		<h3>Algo mas...</h3>
		<h6> h6 </h6>
		<hr/>
		<p class="alfa"> Poseen dos pares de alas membranosas cubiertas de <em class="alfa">escamas coloreadas</em>, que utilizan en la termorregulaci�n, <strong>el cortejo y la se�alizaci�n </strong>. Su aparato bucal es de tipo chupador (v�ase Insecto) provisto de una larga trompa que se enrolla en espiral (espiritrompa) que permanece enrollada en estado de reposo y que les sirve para libar el n�ctar de las flores que polinizan. </p>
			<ol>
				<li class="Item"> mariposa 1 </li>
				<li class="Item"> mariposa 2</li>
				
				<ul class="lista2">
					<li class="Item">colores </li> 
					
					<ol class="lista1">
						<li class="Item"> <a href="colores.html"> Azul </a> </li>
						<li class="Item"> Rojo</li>
					</ol>
					<li class="Item"> formas </li> <a href="http://www.google.com.ar/imgres?imgurl=http://4.bp.blogspot.com/_auiNTDd7jmU/SwXeR3m11EI/AAAAAAAAACY/Y_eEVgGecf0/s1600/normal_mariposas-11.jpg&imgrefurl=http://loracionaldeloirracional.blogspot.com/2009_11_01_archive.html&usg=__Naj-TsJ8qc1n7icWKoIA6IGPkKY=&h=400&w=533&sz=54&hl=es&start=0&zoom=1&tbnid=XuxeLqflQhXkMM:&tbnh=163&tbnw=258&prev=/images%3Fq%3Dmariposas%26um%3D1%26hl%3Des%26sa%3DX%26biw%3D1280%26bih%3D834%26tbs%3Disch:1&um=1&itbs=1&iact=rc&dur=389&ei=uIy4TNLfEoS8lQfP3bm3DA&oei=uIy4TNLfEoS8lQfP3bm3DA&esq=1&page=1&ndsp=24&ved=1t:429,r:0,s:0&tx=208&ty=92"> dibujo </a>
				</ul>
			</ol>
		<h1><em> Fin...Oruga </em> </h1> 
		</div>
	</body>
</html>
	